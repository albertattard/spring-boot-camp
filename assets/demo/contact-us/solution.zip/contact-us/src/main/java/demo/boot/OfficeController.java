package demo.boot;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class OfficeController {

  private final ContactUsService service;

  public OfficeController( final ContactUsService service ) {
    this.service = service;
  }

  @GetMapping( "/offices" )
  public List<Office> offices() {
    return service.list();
  }
}
