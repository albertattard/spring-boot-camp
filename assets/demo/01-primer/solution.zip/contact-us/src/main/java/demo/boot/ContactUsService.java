package demo.boot;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactUsService {

  public List<Office> list() {
    try ( final BufferedReader reader = readCsv() ) {
      return CSVFormat.DEFAULT
        .withFirstRecordAsHeader()
        .withNullString( "" )
        .parse( reader )
        .getRecords()
        .stream()
        .map( this::parseOffice )
        .collect( Collectors.toList() );
    } catch ( final IOException e ) {
      throw new RuntimeException( "Failed to read and parse offices", e );
    }
  }

  private Office parseOffice( final CSVRecord record ) {
    return new Office( record.get( "Name" ),
      record.get( "Address" ),
      record.get( "Phone" ),
      record.get( "Email" ) );
  }

  private BufferedReader readCsv() {
    return new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream( "/offices.csv" ),
        StandardCharsets.UTF_8 )
    );
  }
}
