package demo.boot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName( "Contact us service" )
public class ContactUsServiceTest {

  @Test
  @DisplayName( "should parse the offices from CSV file" )
  public void shouldParseCsv() {
    final ContactUsService service = new ContactUsService();
    final List<Office> offices = service.list();

    final Office cologne = new Office( "ThoughtWorks Cologne", "Lichtstr. 43i, 50825 Cologne, Germany", "+49 221 64 30 70 63", "contact-de@thoughtworks.com" );
    final Office london = new Office( "ThoughtWorks London", "76 Wardour Street, London W1F 0UR, UK", "+44 (0)20 3437 0990", null );

    assertEquals( 6, offices.size() );
    assertEquals( cologne, offices.get( 0 ) );
    assertEquals( london, offices.get( 4 ) );
  }
}
